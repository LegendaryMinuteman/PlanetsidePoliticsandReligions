﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RimWorld;
using Verse.AI;
using Verse;

namespace PoliticsandReligions
{
    class MentalBreakWorker_ChangeReligions : MentalBreakWorker
    {

        // I don't know the purpose of this segment of code, it was copied from Basarab's Religions of RimWorld mod https://ludeon.com/forums/index.php?topic=47948.msg452744#msg452744

        public override float CommonalityFor(Pawn pawn)
        {
            float baseCommonality = this.def.baseCommonality;
            if (pawn.Faction == Faction.OfPlayer && this.def.commonalityFactorPerPopulationCurve != null)
                baseCommonality *= this.def.commonalityFactorPerPopulationCurve.Evaluate((float)PawnsFinder.AllMaps_FreeColonists.Count<Pawn>());
            if (pawn.story.traits.allTraits.Any(x => x.def is TraitDef_ReligionsTrait))
                return 0;
            return baseCommonality;
        }

        // Whether or not the pawn already has a religion forks the code down two separate paths. This is to avoid the pawn randomly switching to his own religion.

        public override bool TryStart(Pawn pawn, string reason, bool causedByMood)
        {
            Random rn = new Random();
            int chance = rn.Next(1, 20);
            if (pawn.story.traits.allTraits.Any(x => x.def is TraitDef_ReligionsTrait))
            {
                Trait oldReligion = pawn.story.traits.allTraits.Find(x => x.def is TraitDef_ReligionsTrait);
                Trait newReligion = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.FindAll(x => x is TraitDef_ReligionsTrait && x.defName != oldReligion.def.defName).RandomElement());
                if (chance <= 18)
                {
                    pawn.story.traits.allTraits.Remove(oldReligion);
                    pawn.story.traits.allTraits.Add(newReligion);

                    // check to see if a theocrat is becoming atheist/antitheist/agnostic

                    if (newReligion.def.defName == "ReligionsAtheist" || newReligion.def.defName == "ReligionsAntitheist" || newReligion.def.defName == "ReligionsAgnostic")
                    {
                        if (pawn.story.traits.allTraits.Any(x => x.def is TraitDef_PoliticsTrait && x.def.defName == "PoliticsTheocrat"))
                        {
                            Trait newIdeology = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.FindAll(x => x is TraitDef_PoliticsTrait && x.defName != "PoliticsTheocrat").RandomElement());
                            Trait Theocracy = pawn.story.traits.allTraits.Find(x => x.def is TraitDef_PoliticsTrait && x.def.defName == "PoliticsTheocrat");
                            pawn.story.traits.allTraits.Remove(Theocracy);
                            pawn.story.traits.allTraits.Add(newIdeology);
                        }
                    }
                }
                return base.TryStart(pawn, reason, causedByMood);
            }
            else
            {
                Trait newReligion = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.FindAll(x => x is TraitDef_ReligionsTrait).RandomElement());
                if (chance <= 18)
                {
                    pawn.story.traits.allTraits.Add(newReligion);

                    // check to see if a theocrat is becoming atheist/antitheist/agnostic

                    if (newReligion.def.defName == "ReligionsAtheist" || newReligion.def.defName == "ReligionsAntitheist" || newReligion.def.defName == "ReligionsAgnostic")
                    {
                        if (pawn.story.traits.allTraits.Any(x => x.def is TraitDef_PoliticsTrait && x.def.defName == "PoliticsTheocrat"))
                        {
                            Trait newIdeology = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.FindAll(x => x is TraitDef_PoliticsTrait && x.defName != "PoliticsTheocrat").RandomElement());
                            Trait Theocracy = pawn.story.traits.allTraits.Find(x => x.def is TraitDef_PoliticsTrait && x.def.defName == "PoliticsTheocrat");
                            pawn.story.traits.allTraits.Remove(Theocracy);
                            pawn.story.traits.allTraits.Add(newIdeology);
                        }
                    }
                }
                return base.TryStart(pawn, reason, causedByMood);
            }
        }
    }
}