﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using RimWorld;
using Verse;

namespace PoliticsandReligions
{
    class ThoughtWorker_ReligionsIntolerable : ThoughtWorker
    {
        protected override ThoughtState CurrentSocialStateInternal(Pawn thisPawn, Pawn thatPawn)
        {
            if (!thisPawn.RaceProps.Humanlike)
                return (ThoughtState)false;
            if (!RelationsUtility.PawnsKnowEachOther(thisPawn, thatPawn))
                return (ThoughtState)false;
            if (thatPawn.def != thisPawn.def)
                return (ThoughtState)false;
            if (!thisPawn.story.traits.allTraits.Any(x => x.def is TraitDef_ReligionsTrait))
                return (ThoughtState)false;
            if (!thatPawn.story.traits.allTraits.Any(x => x.def is TraitDef_ReligionsTrait))
                return (ThoughtState)false;
            TraitDef_ReligionsTrait pawnReligions = thisPawn.story.traits.allTraits.Find(x => x.def is TraitDef_ReligionsTrait).def as TraitDef_ReligionsTrait;
            TraitDef otherReligions = thatPawn.story.traits.allTraits.Find(x => x.def is TraitDef_ReligionsTrait).def;
            if (pawnReligions.ReligionsIntolerable.Contains(otherReligions))
                return (ThoughtState)true;
            return (ThoughtState)false;
        }
    }
}