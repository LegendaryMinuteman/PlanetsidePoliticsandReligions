﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Verse;
using Verse.AI;
using RimWorld;

namespace PoliticsandReligions
{
    public class CompUseEffect_SetReligions : CompUseEffect
    {
        public override void DoEffect(Pawn user)
        {
            Random rn = new Random();
            int intCheck = (rn.Next(1, 20)-5);
            SkillDef intellectual = SkillDefOf.Intellectual;
            int intellect = user.skills.GetSkill(intellectual).Level;
            this.parent.TryGetQuality(out QualityCategory qc);
            int qualityInt = 0;
            string qualityString = "null";
            if (qc == QualityCategory.Awful)
            {
                qualityInt = -5;
                qualityString = "awful";
            }
            else if (qc == QualityCategory.Poor)
            {
                qualityInt = -3;
                qualityString = "poor";
            }
            else if (qc == QualityCategory.Normal)
            {
                qualityInt = 0;
                qualityString = "normal";
            }
            else if (qc == QualityCategory.Good)
            {
                qualityInt = 1;
                qualityString = "good";
            }
            else if (qc == QualityCategory.Excellent)
            {
                qualityInt = 2;
                qualityString = "excellent";
            }
            else if (qc == QualityCategory.Masterwork)
            {
                qualityInt = 3;
                qualityString = "masterwork";
            }
            else if (qc == QualityCategory.Legendary)
            {
                qualityInt = 5;
                qualityString = "legendary";
            }
            // everything comes together for the final check

            if (intCheck + qualityInt >= intellect)
            {
                ThingDef apologetic = this.parent.def;
                Trait newReligion = new Trait();

                // check to see if a theocrat is becoming atheist/antitheist/agnostic

                if (apologetic.defName == "Religions_Book_Atheist")
                {
                    newReligion = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_ReligionsTrait && x.defName == "ReligionsAtheist"));
                    if (user.story.traits.allTraits.Any(x => x.def is TraitDef_PoliticsTrait && x.def.defName == "PoliticsTheocrat"))
                    {
                        Trait newIdeology = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_PoliticsTrait && x.defName != "PoliticsTheocrat"));
                        Trait Theocracy = user.story.traits.allTraits.Find(x => x.def is TraitDef_PoliticsTrait && x.def.defName == "PoliticsTheocrat");
                        user.story.traits.allTraits.Remove(Theocracy);
                        user.story.traits.allTraits.Add(newIdeology);
                    }
                }
                else if (apologetic.defName == "Religions_Book_Antitheist")
                {
                    newReligion = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_ReligionsTrait && x.defName == "ReligionsAntitheist"));
                    if (user.story.traits.allTraits.Any(x => x.def is TraitDef_PoliticsTrait && x.def.defName == "PoliticsTheocrat"))
                    {
                        Trait newIdeology = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_PoliticsTrait && x.defName != "PoliticsTheocrat"));
                        Trait Theocracy = user.story.traits.allTraits.Find(x => x.def is TraitDef_PoliticsTrait && x.def.defName == "PoliticsTheocrat");
                        user.story.traits.allTraits.Remove(Theocracy);
                        user.story.traits.allTraits.Add(newIdeology);
                    }
                }
                else if (apologetic.defName == "Religions_Book_Agnostic")
                {
                    newReligion = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_ReligionsTrait && x.defName == "ReligionsAgnostic"));
                    if (user.story.traits.allTraits.Any(x => x.def is TraitDef_PoliticsTrait && x.def.defName == "PoliticsTheocrat"))
                    {
                        Trait newIdeology = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_PoliticsTrait && x.defName != "PoliticsTheocrat"));
                        Trait Theocracy = user.story.traits.allTraits.Find(x => x.def is TraitDef_PoliticsTrait && x.def.defName == "PoliticsTheocrat");
                        user.story.traits.allTraits.Remove(Theocracy);
                        user.story.traits.allTraits.Add(newIdeology);
                    }
                }
                else if (apologetic.defName == "Religions_Book_Christian")
                {
                    newReligion = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_ReligionsTrait && x.defName == "ReligionsChristian"));
                }
                else if (apologetic.defName == "Religions_Book_Judaism")
                {
                    newReligion = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_ReligionsTrait && x.defName == "ReligionsJudaism"));
                }
                else if (apologetic.defName == "Religions_Book_Taoism")
                {
                    newReligion = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_ReligionsTrait && x.defName == "ReligionsTaoism"));
                }
                else if (apologetic.defName == "Religions_Book_Buddhism")
                {
                    newReligion = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_ReligionsTrait && x.defName == "ReligionsBuddhism"));
                }
                else if (apologetic.defName == "Religions_Book_Sikhism")
                {
                    newReligion = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_ReligionsTrait && x.defName == "ReligionsSikhism"));
                }
                else if (apologetic.defName == "Religions_Book_Hinduism")
                {
                    newReligion = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_ReligionsTrait && x.defName == "ReligionsHinduism"));
                }
                else if (apologetic.defName == "Religions_Book_Jainism")
                {
                    newReligion = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_ReligionsTrait && x.defName == "ReligionsJainism"));
                }
                else if (apologetic.defName == "Religions_Book_Zoroastrianism")
                {
                    newReligion = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_ReligionsTrait && x.defName == "ReligionsZoroastrianism"));
                }
                else if (apologetic.defName == "Religions_Book_Islamic")
                {
                    newReligion = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_ReligionsTrait && x.defName == "ReligionsIslamic"));
                }
                else if (apologetic.defName == "Religions_Book_Pagan")
                {
                    newReligion = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_ReligionsTrait && x.defName == "ReligionsPagan"));
                }
                else if (apologetic.defName == "Religions_Book_Mysticism")
                {
                    newReligion = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_ReligionsTrait && x.defName == "ReligionsMysticism"));
                }
                else if (apologetic.defName == "Religions_Book_Mother")
                {
                    newReligion = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_ReligionsTrait && x.defName == "ReligionsMother"));
                }
                else if (apologetic.defName == "Religions_Book_Father")
                {
                    newReligion = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_ReligionsTrait && x.defName == "ReligionsFather"));
                }
                else if (apologetic.defName == "Religions_Book_Archon")
                {
                    newReligion = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_ReligionsTrait && x.defName == "ReligionsArchon"));
                }
                else if (apologetic.defName == "Religions_Book_Animism")
                {
                    newReligion = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_ReligionsTrait && x.defName == "ReligionsAnimism"));
                }
                else if (apologetic.defName == "Religions_Book_Sacrifice")
                {
                    newReligion = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_ReligionsTrait && x.defName == "ReligionsSacrifice"));
                }
                
                // check for old religion trait and remove it

                    if (user.story.traits.allTraits.Any(x => x.def is TraitDef_ReligionsTrait))
                    {
                        Trait oldReligion = user.story.traits.allTraits.Find(x => x.def is TraitDef_ReligionsTrait);
                        user.story.traits.allTraits.Remove(oldReligion);
                    }

                // back to our regularly scheduled programming

                string success = user.Name.ToString() + " found the " + qualityString + " apologetic very compelling.";
                user.story.traits.allTraits.Add(newReligion);
                Messages.Message(success, MessageTypeDefOf.PositiveEvent);
            }
            else
            {
                string fail = user.Name.ToString() + " found the " + qualityString + " apologetic unconvincing.";
                Messages.Message(fail, MessageTypeDefOf.NegativeEvent);
            }
        }
    }
}