﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using RimWorld;
using Verse;

namespace PoliticsandReligions
{
    class ThoughtWorker_PoliticalRivalry : ThoughtWorker
    {
        protected override ThoughtState CurrentSocialStateInternal(Pawn thisPawn, Pawn thatPawn)
        {
            if (!thisPawn.RaceProps.Humanlike)
                return (ThoughtState)false;
            if (!RelationsUtility.PawnsKnowEachOther(thisPawn, thatPawn))
                return (ThoughtState)false;
            if (thatPawn.def != thisPawn.def)
                return (ThoughtState)false;
            if (!thisPawn.story.traits.allTraits.Any(x => x.def is TraitDef_PoliticsTrait))
                return (ThoughtState)false;
            if (!thatPawn.story.traits.allTraits.Any(x => x.def is TraitDef_PoliticsTrait))
                return (ThoughtState)false;
            TraitDef_PoliticsTrait pawnPolitics = thisPawn.story.traits.allTraits.Find(x => x.def is TraitDef_PoliticsTrait).def as TraitDef_PoliticsTrait;
            TraitDef otherIdeology = thatPawn.story.traits.allTraits.Find(x => x.def is TraitDef_PoliticsTrait).def;
            if (pawnPolitics.PoliticalRivalry.Contains(otherIdeology))
                return (ThoughtState)true;
            return (ThoughtState)false;
        }
    }
}