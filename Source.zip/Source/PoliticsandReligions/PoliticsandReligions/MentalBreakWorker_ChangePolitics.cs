﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RimWorld;
using Verse.AI;
using Verse;

namespace PoliticsandReligions
{
    class MentalBreakWorker_ChangePolitics : MentalBreakWorker
    {

        // I don't know the purpose of this segment of code, it was copied from Basarab's Religions of RimWorld mod https://ludeon.com/forums/index.php?topic=47948.msg452744#msg452744

        public override float CommonalityFor(Pawn pawn)
        {
            float baseCommonality = this.def.baseCommonality;
            if (pawn.Faction == Faction.OfPlayer && this.def.commonalityFactorPerPopulationCurve != null)
                baseCommonality *= this.def.commonalityFactorPerPopulationCurve.Evaluate((float)PawnsFinder.AllMaps_FreeColonists.Count<Pawn>());
            if (pawn.story.traits.allTraits.Any(x => x.def is TraitDef_PoliticsTrait))
                return 0;
            return baseCommonality;
        }

        // Whether or not the pawn already has an ideology forks the code down two separate paths. This is to avoid the pawn randomly switching to his own ideology.

        public override bool TryStart(Pawn pawn, string reason, bool causedByMood)
        {
            Random rn = new Random();
            int chance = rn.Next(1, 20);
            if (pawn.story.traits.allTraits.Any(x => x.def is TraitDef_PoliticsTrait))
            {
                Trait oldIdeology = pawn.story.traits.allTraits.Find(x => x.def is TraitDef_PoliticsTrait);
                Trait newIdeology = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.FindAll(x => x is TraitDef_PoliticsTrait && x.defName != oldIdeology.def.defName).RandomElement());
                if (chance <= 18)
                {
                    pawn.story.traits.allTraits.Remove(oldIdeology);
                    pawn.story.traits.allTraits.Add(newIdeology);

                    // check to see if an atheist/antitheist/agnostic is becoming a theocrat, if so, remove their lack of faith and pick their new object of zeal

                    if (newIdeology.def.defName == "PoliticsTheocrat")
                    {
                        Trait newReligion = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_ReligionsTrait && x.defName != "ReligionsAtheist" || x is TraitDef_ReligionsTrait && x.defName != "ReligionsAntitheist" || x is TraitDef_ReligionsTrait && x.defName != "ReligionsAgnostic"));
                        if (pawn.story.traits.allTraits.Any(x => x.def is TraitDef_ReligionsTrait && x.def.defName == "ReligionsAtheist"))
                        {
                            Trait Atheism = pawn.story.traits.allTraits.Find(x => x.def is TraitDef_ReligionsTrait && x.def.defName == "ReligionsAtheist");
                            pawn.story.traits.allTraits.Remove(Atheism);
                            pawn.story.traits.allTraits.Add(newReligion);
                        }
                        else if (pawn.story.traits.allTraits.Any(x => x.def is TraitDef_ReligionsTrait && x.def.defName == "ReligionsAntitheist"))
                        {
                            Trait Antitheism = pawn.story.traits.allTraits.Find(x => x.def is TraitDef_ReligionsTrait && x.def.defName == "ReligionsAntitheist");
                            pawn.story.traits.allTraits.Remove(Antitheism);
                            pawn.story.traits.allTraits.Add(newReligion);
                        }
                        else if (pawn.story.traits.allTraits.Any(x => x.def is TraitDef_ReligionsTrait && x.def.defName == "ReligionsAgnostic"))
                        {
                            Trait Agnostic = pawn.story.traits.allTraits.Find(x => x.def is TraitDef_ReligionsTrait && x.def.defName == "ReligionsAgnostic");
                            pawn.story.traits.allTraits.Remove(Agnostic);
                            pawn.story.traits.allTraits.Add(newReligion);
                        }
                    }

                }
                return base.TryStart(pawn, reason, causedByMood);
            }
            else
            {
                Trait newIdeology = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.FindAll(x => x is TraitDef_PoliticsTrait).RandomElement());
                if (chance <= 18)
                {
                    pawn.story.traits.allTraits.Add(newIdeology);

                    // check to see if an atheist/antitheist/agnostic is becoming a theocrat, if so, remove their lack of faith and pick their new object of zeal

                    if (newIdeology.def.defName == "PoliticsTheocrat")
                    {
                        Trait newReligion = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_ReligionsTrait && x.defName != "ReligionsAtheist" || x is TraitDef_ReligionsTrait && x.defName != "ReligionsAntitheist" || x is TraitDef_ReligionsTrait && x.defName != "ReligionsAgnostic"));
                        if (pawn.story.traits.allTraits.Any(x => x.def is TraitDef_ReligionsTrait && x.def.defName == "ReligionsAtheist"))
                        {
                            Trait Atheism = pawn.story.traits.allTraits.Find(x => x.def is TraitDef_ReligionsTrait && x.def.defName == "ReligionsAtheist");
                            pawn.story.traits.allTraits.Remove(Atheism);
                            pawn.story.traits.allTraits.Add(newReligion);
                        }
                        else if (pawn.story.traits.allTraits.Any(x => x.def is TraitDef_ReligionsTrait && x.def.defName == "ReligionsAntitheist"))
                        {
                            Trait Antitheism = pawn.story.traits.allTraits.Find(x => x.def is TraitDef_ReligionsTrait && x.def.defName == "ReligionsAntitheist");
                            pawn.story.traits.allTraits.Remove(Antitheism);
                            pawn.story.traits.allTraits.Add(newReligion);
                        }
                        else if (pawn.story.traits.allTraits.Any(x => x.def is TraitDef_ReligionsTrait && x.def.defName == "ReligionsAgnostic"))
                        {
                            Trait Agnostic = pawn.story.traits.allTraits.Find(x => x.def is TraitDef_ReligionsTrait && x.def.defName == "ReligionsAgnostic");
                            pawn.story.traits.allTraits.Remove(Agnostic);
                            pawn.story.traits.allTraits.Add(newReligion);
                        }
                    }
                }
                return base.TryStart(pawn, reason, causedByMood);
            }
        }
    }
}