﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Verse;
using Verse.AI;
using RimWorld;

namespace PoliticsandReligions
{
    public class CompUseEffect_SetPolitics : CompUseEffect
    {
        public override void DoEffect(Pawn user)
        {

            // to make the final check a random number, the intellect of the reader, and the quality of the book need to be declared/found

            Random rn = new Random();
            int intCheck = rn.Next(1, 20);

            // d20

            SkillDef intellectual = SkillDefOf.Intellectual;
            int intellect = user.skills.GetSkill(intellectual).Level;

            // intellect

            this.parent.TryGetQuality(out QualityCategory qc); // Thanks LWM at Ludeon Forums for elucidating this for me.
            int qualityInt = 0;

            // quality

            string qualityString = "null";
            if (qc == QualityCategory.Awful)
            {
                qualityInt = -5;
                qualityString = "awful";
            }
            else if (qc == QualityCategory.Poor)
            {
                qualityInt = -3;
                qualityString = "poor";
            }
            else if (qc == QualityCategory.Normal)
            {
                qualityInt = 0;
                qualityString = "normal";
            }
            else if (qc == QualityCategory.Good)
            {
                qualityInt = 1;
                qualityString = "good";
            }
            else if (qc == QualityCategory.Excellent)
            {
                qualityInt = 2;
                qualityString = "excellent";
            }
            else if (qc == QualityCategory.Masterwork)
            {
                qualityInt = 3;
                qualityString = "masterwork";
            }
            else if (qc == QualityCategory.Legendary)
            {
                qualityInt = 5;
                qualityString = "legendary";
            }
            // here goes nothing

            if (intCheck + qualityInt >= intellect)
            {
                ThingDef polemic = this.parent.def;
                Trait newIdeology = new Trait();
                // now that something is actually going to happen, determine the type of book

                if (polemic.defName == "Politics_Book_Anarchy")
                {
                    newIdeology = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_PoliticsTrait && x.defName == "PoliticsAnarchist"));
                }
                else if (polemic.defName == "Politics_Book_Despotism")
                {
                    newIdeology = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_PoliticsTrait && x.defName == "PoliticsDespot"));
                }
                else if (polemic.defName == "Politics_Book_Monarchy")
                {
                    newIdeology = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_PoliticsTrait && x.defName == "PoliticsMonarchist"));
                }
                else if (polemic.defName == "Politics_Book_Theocracy")
                {
                    newIdeology = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_PoliticsTrait && x.defName == "PoliticsTheocrat"));

                    // check to see if an atheist/antitheist/agnostic is becoming a theocrat

                    Trait newReligion = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_ReligionsTrait && x.defName != "ReligionsAtheist"  && x.defName != "ReligionsAntitheist" && x.defName != "ReligionsAgnostic"));
                    if (user.story.traits.allTraits.Any(x => x.def is TraitDef_ReligionsTrait && x.def.defName == "ReligionsAtheist"))
                    {
                        Trait Atheism = user.story.traits.allTraits.Find(x => x.def is TraitDef_ReligionsTrait && x.def.defName == "ReligionsAtheist");
                        user.story.traits.allTraits.Remove(Atheism);
                        user.story.traits.allTraits.Add(newReligion);
                    }
                    else if (user.story.traits.allTraits.Any(x => x.def is TraitDef_ReligionsTrait && x.def.defName == "ReligionsAntitheist"))
                    {
                        Trait Antitheism = user.story.traits.allTraits.Find(x => x.def is TraitDef_ReligionsTrait && x.def.defName == "ReligionsAntitheist");
                        user.story.traits.allTraits.Remove(Antitheism);
                        user.story.traits.allTraits.Add(newReligion);
                    }
                    else if (user.story.traits.allTraits.Any(x => x.def is TraitDef_ReligionsTrait && x.def.defName == "ReligionsAgnostic"))
                    {
                        Trait Agnostic = user.story.traits.allTraits.Find(x => x.def is TraitDef_ReligionsTrait && x.def.defName == "ReligionsAgnostic");
                        user.story.traits.allTraits.Remove(Agnostic);
                        user.story.traits.allTraits.Add(newReligion);
                    }
                }
                else if (polemic.defName == "Politics_Book_Socialism")
                {
                    newIdeology = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_PoliticsTrait && x.defName == "PoliticsSocialist"));
                }
                else if (polemic.defName == "Politics_Book_Communism")
                {
                    newIdeology = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_PoliticsTrait && x.defName == "PoliticsCommunist"));
                }
                else if (polemic.defName == "Politics_Book_Fascism")
                {
                    newIdeology = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_PoliticsTrait && x.defName == "PoliticsFascist"));
                }
                else if (polemic.defName == "Politics_Book_Democracy")
                {
                    newIdeology = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_PoliticsTrait && x.defName == "PoliticsDemocrat"));
                }
                else if (polemic.defName == "Politics_Book_Republic")
                {
                    newIdeology = new Trait(DefDatabase<TraitDef>.AllDefsListForReading.Find(x => x is TraitDef_PoliticsTrait && x.defName == "PoliticsRepublican"));
                }

                // after determining the type, check for an existing political trait and remove it

                if (user.story.traits.allTraits.Any(x => x.def is TraitDef_PoliticsTrait))
                {
                    Trait oldIdeology = user.story.traits.allTraits.Find(x => x.def is TraitDef_PoliticsTrait);
                    user.story.traits.allTraits.Remove(oldIdeology);
                }
                string success = user.Name.ToString() + " found the " + qualityString + " polemic very compelling.";
                user.story.traits.allTraits.Add(newIdeology);
                Messages.Message(success, MessageTypeDefOf.PositiveEvent);
            }
            else
            {
                string fail = user.Name.ToString() + " found the " + qualityString + " polemic unconvincing.";
                Messages.Message(fail, MessageTypeDefOf.NegativeEvent);
            }
        }
    }
}