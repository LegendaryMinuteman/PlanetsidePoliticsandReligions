﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using RimWorld;
using Verse;

namespace PoliticsandReligions
{
    class TraitDef_ReligionsTrait : TraitDef
    {
        public List<TraitDef> ReligionsSame = new List<TraitDef>();
        public List<TraitDef> ReligionsDifferent = new List<TraitDef>();
        public List<TraitDef> ReligionsIntolerable = new List<TraitDef>();
        public bool isExotheology;
    }
}